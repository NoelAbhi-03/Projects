import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/UserAccount")
public class UserAccount extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String firstName = request.getParameter("first_name");
        String lastName = request.getParameter("last_name");

        request.setAttribute("username", username);
        request.setAttribute("email", email);
        request.setAttribute("first_name", firstName);
        request.setAttribute("last_name", lastName);

        request.getRequestDispatcher("user_account.html").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String newPassword = request.getParameter("password");

        // Update password logic here
        System.out.println("Password updated to: " + newPassword);

        response.sendRedirect("UserAccount");
    }
}